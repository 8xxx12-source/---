# MOA — GitHub 소스코드 내보내기

2026-10-02 배포 버전 33 / Rule 5.0 / 작업군 43개 기준.

## GitHub에 올리기
ZIP을 풀고 폴더 안 파일 전체를 저장소에 올리세요. ZIP 자체만 올리면 소스 탐색이 불편합니다.
화면 HTML은 `src/index.html`, 화면 동작은 `src/app.js`, 디자인은 `src/style.css`입니다.
백엔드는 `src/worker.js`, DB 스키마는 `db/schema.ts`, 마이그레이션은 `drizzle/`에 있습니다.

## 중요: index.html 하나로 전체 서비스는 실행되지 않습니다
GitHub 저장소는 코드 보관용입니다. GitHub Pages에 HTML만 올리면 로그인·DB·민원 저장·서버 API가 작동하지 않습니다.
현재 MOA는 Cloudflare Workers 호환 서버와 D1 DB를 사용합니다. 다른 호스팅으로 옮길 경우 서버 배포 및 DB 연결을 별도로 해야 합니다.
이 ZIP은 현재 운영 사이트·사용자·DB를 변경하지 않습니다. 기존 운영 DB 데이터 및 실제 Secret은 포함하지 않습니다.

## 빌드
Node.js 24 환경에서:
```
npm ci
npm run build
```
빌드 결과: dist/server/index.js. `src/index.html`의 /app.js, /style.css 경로는 서버가 제공합니다.
`npm run dev`는 현재 원본 프로젝트에 없습니다. 로컬 서버 실행에는 Workers/D1 개발 환경을 따로 구성해야 합니다.

## 환경변수
.env.example에는 이름만 있습니다. 서버 환경에 키를 설정하세요. .env 파일을 자동 로딩하는 코드는 이 프로젝트에 없습니다.
DB는 문자열 환경변수가 아닌 D1 바인딩입니다.
MOA_LOGIN_USERNAME/MOA_PASSWORD_HASH/MOA_PASSWORD_SALT는 기존 관리자 계정 이전용 선택 설정입니다. 실제 값은 포함하지 않습니다.
.openai/hosting.json은 기존 Sites 프로젝트 연결 정보이며 인증키가 아닙니다. 새 사이트를 만들려는 목적으로 기존 DB에 마이그레이션을 적용하지 마세요.

## 포함하지 않은 자료
실제 회원·민원 데이터, API 키, 실제 비밀번호, .git 이력, node_modules, 빌드 캐시, 운영 테스트 결과 및 로그.
