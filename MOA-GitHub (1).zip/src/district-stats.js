const DAY=86400000,OFFSET=9*3600000;
export function periodWindow(period,now=Date.now()){
 const today=new Date(Math.floor((now+OFFSET)/DAY)*DAY),end=+today+DAY-OFFSET;
 let days=period==='7'?7:30;
 if(period==='3m'){const start=new Date(today);const targetMonth=start.getUTCMonth()-3;start.setUTCDate(1);start.setUTCMonth(targetMonth);const last=new Date(Date.UTC(start.getUTCFullYear(),start.getUTCMonth()+1,0)).getUTCDate();start.setUTCDate(Math.min(today.getUTCDate(),last));days=Math.round((+today-+start)/DAY)+1;}
 return {start:end-days*DAY,end,previousStart:end-2*days*DAY,days};
}
export function districtStats(rows,names,period,now=Date.now()){
 const w=periodWindow(period,now),map=new Map(names.map(name=>[name,{name,total:0,previous:0,daily:Array(w.days).fill(0)}]));let unknown=0;
 for(const row of rows){const time=Date.parse(row.created);if(!Number.isFinite(time)||time<w.previousStart||time>=w.end||time>now)continue;const entry=row.region==='서울특별시'?map.get(row.district):null;if(!entry){if(time>=w.start)unknown++;continue;}if(time<w.start)entry.previous++;else{entry.total++;entry.daily[Math.floor((time-w.start)/DAY)]++;}}
 const dates=Array.from({length:w.days},(_,i)=>new Date(w.start+OFFSET+i*DAY).toISOString().slice(0,10));
 return {period,days:w.days,dates,unknown,asOf:new Date(now).toISOString(),districts:[...map.values()].sort((a,b)=>b.total-a.total||a.name.localeCompare(b.name,'ko')),scope:'MOA 등록 민원 · 삭제·제외 건 제외'};
}
