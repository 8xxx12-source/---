// Official contract manual: [sequence^role^joint type^company^representative^country^share^creditor^contact^business number]. Only company and business number retained.
export function parseSuppliers(value){return [...String(value||'').matchAll(/\[([^\[\]]+)\]/g)].map(m=>m[1].split('^').map(s=>s.trim())).filter(a=>a.length===10&&/^[0-9]{10}$/.test(a[9])).map(a=>({name:a[3].slice(0,200),bizno:a[9]})).slice(0,20)}
import services from './procurement-services.json' with {type:'json'};
import {XMLParser,XMLValidator} from 'fast-xml-parser';
export {services};
const array=x=>x==null||x===''?[]:Array.isArray(x)?x:[x];
const fields={vendors:['bizno','corpNm','adrs','rgnNm','corpBsnsDivNm','rgstDt','chgDt'],vendorIndustries:['bizno','indstrytyCd','indstrytyNm','indstrytyStatsNm','vldPrdExprtDt'],contracts:['untyCntrctNo','cnstwkNm','cntrctInsttNm','cntrctCnclsDate','totCntrctAmt','thtmCntrctAmt','bsnsDivNm','cntrctDtlInfoUrl','cntrctNm','pubPrcrmntClsfcNm'],prices:['pblctDate','cnstwkDivCdNm','uprcDivNm','qtyCalcCtyclcd','prdnm','spec','unit','mtrlcstUprc','lbrcstUprc','gnrexpnsUprc','uprcAplCndtnCntnts'],industries:['indstrytyCd','indstrytyNm','indstrytyUseYn','baseLawordNm','baseLawordArtclClauseNm','baseLawordUrl'],bids:['bidNtceNo','bidNtceNm','ntceInsttNm','dminsttNm','bidNtceDt','bidClseDt','presmptPrce']};
const safe=x=>typeof x==='string'||typeof x==='number'?String(x).slice(0,1500):'';
function dates(){const now=new Date(Date.now()+9*3600000),start=new Date(now-29*86400000);return {start:start.toISOString().slice(0,10).replaceAll('-',''),end:now.toISOString().slice(0,10).replaceAll('-','')}}
export function parameters(kind,query={}){const d=dates(),p={serviceKey:'',numOfRows:'100',pageNo:'1',type:'json'};
 if(kind==='industries')return {...p,indstrytyNm:query.term||'포장',indstrytyUseYn:'Y'};
 if(kind==='vendorIndustries')return {...p,inqryDiv:'1',bizno:query.bizno};
 if(kind==='vendors'&&query.bizno)return {...p,inqryDiv:'3',bizno:query.bizno};
 if(kind==='vendors')return {...p,inqryDiv:'1',inqryBgnDt:d.start+'0000',inqryEndDt:d.end+'2359',...(query.term?{corpNm:query.term}:{})};
 if(kind==='prices')return {...p,inqryDiv:'1',inqryBgnDate:d.start,inqryEndDate:d.end};
 if(kind==='contracts')return {...p,inqryDiv:'1',inqryBgnDate:d.start,inqryEndDate:d.end,insttNm:query.district||'송파구',...(query.term?{[query.workType==='goods'?'prdctClsfcNoNm':query.workType==='service'?'cntrctNm':'cnstwkNm']:query.term}:{})};
 return {...p,inqryDiv:'1',inqryBgnDt:d.start+'0000',inqryEndDt:d.end+'2359',ntceInsttNm:query.district||'송파구',...(query.term?{bidNtceNm:query.term}:{})};
}
export function parseProcurement(raw,kind){let d;if(raw.trim().startsWith('{'))d=JSON.parse(raw);else{if(/<!DOCTYPE|<!ENTITY/i.test(raw)||XMLValidator.validate(raw)!==true)throw Error('FORMAT');d=new XMLParser({parseTagValue:false,processEntities:false}).parse(raw)}
 const r=d.response||d,header=r.header||{},error=d.OpenAPI_ServiceResponse?.cmmMsgHeader;
 const findCode=(v,depth=0)=>{if(!v||typeof v!=='object'||depth>5)return null;for(const [k,x] of Object.entries(v)){if(['resultCode','returnReasonCode','code'].includes(k)&&/^[A-Z0-9_-]{1,40}$/.test(String(x)))return String(x);const nested=findCode(x,depth+1);if(nested)return nested}return null};
 const code=safe(header.resultCode??error?.returnReasonCode??findCode(d)??'UNKNOWN');const resultCode=/^[A-Za-z0-9_-]{1,40}$/.test(code)?code:'UNKNOWN';
 const rows=array(r.body?.items?.item??r.body?.items).filter(x=>x&&typeof x==='object');
 return {structure:Object.keys(d).filter(k=>/^[a-zA-Z0-9_.-]{1,80}$/.test(k)).slice(0,8),resultCode,ok:['00','000','0'].includes(resultCode),totalCount:Number(r.body?.totalCount)||0,items:rows.slice(0,100).map(x=>({...Object.fromEntries(fields[kind].map(k=>[k,safe(x[k])])),...(kind==='contracts'?{suppliers:parseSuppliers(x.corpList)}:{})}))};
}
export async function procurement(env,kind,query={}){let service=services[kind];if(kind==='contracts'&&['goods','service'].includes(query.workType)){const operation=query.workType==='goods'?'getCntrctInfoListThngPPSSrch':'getCntrctInfoListServcPPSSrch';service={...service,operation,endpoint:'https://apis.data.go.kr/1230000/ao/CntrctInfoService/'+operation}}if(!service)return {status:'invalid',message:'지원하지 않는 조회입니다.'};
 const keyName=({contracts:'G2B_CONTRACT_API_KEY',industries:'G2B_INDUSTRY_API_KEY',prices:'G2B_PRICE_API_KEY'})[kind]||'G2B_API_KEY';const key=(env[keyName]||env.G2B_API_KEY)?.trim();const diagnostic={keyPresent:!!key,keyName:env[keyName]?keyName:'G2B_API_KEY',httpStatus:null,resultCode:null,operation:service.operation,attemptedAt:new Date().toISOString()};
 if(!key)return {status:'not_configured',message:'공공조달 연결을 준비 중입니다.',diagnostic};
 const params=parameters(kind,query);const cacheKey=JSON.stringify(['g2b-v3.1',service.operation,params]);let cached;
 try{cached=await env.DB.prepare('SELECT payload,fetched_at FROM procurement_cache WHERE id=?').bind(cacheKey).first();if(cached?.payload&&Date.now()-cached.fetched_at<(JSON.parse(cached.payload).status==='ok'?3600000:60000))return {...JSON.parse(cached.payload),cached:true};}catch{}
 let result;try{let decoded=key;try{decoded=decodeURIComponent(key)}catch{}params.serviceKey=decoded;
 const url=service.endpoint+'?'+new URLSearchParams(params);const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);let raw;
 try{const res=await fetch(url,{signal:controller.signal,redirect:'manual'});diagnostic.httpStatus=res.status;const reader=res.body.getReader();let chunks=[],n=0;while(true){const v=await reader.read();if(v.done)break;n+=v.value.length;if(n>2000000){await reader.cancel();throw Error('SIZE')}chunks.push(v.value)}const bytes=new Uint8Array(n);let i=0;for(const c of chunks){bytes.set(c,i);i+=c.length}raw=new TextDecoder().decode(bytes)}finally{clearTimeout(timer)}
 diagnostic.responseBytes=raw.length;diagnostic.responseFormat=raw.trim().startsWith('{')?'json':raw.trim().startsWith('<')?'xml_or_html':'text';
 let parsed;try{parsed=parseProcurement(raw,kind)}catch{diagnostic.failure=diagnostic.httpStatus!==200?'HTTP_ERROR':'INVALID_RESPONSE';diagnostic.providerSignal=/SERVICE_KEY_IS_NOT_REGISTERED_ERROR/.test(raw)?'SERVICE_KEY_IS_NOT_REGISTERED_ERROR':/SERVICE_ACCESS_DENIED_ERROR/.test(raw)?'SERVICE_ACCESS_DENIED_ERROR':/Forbidden/i.test(raw)?'FORBIDDEN':null;throw Error('PARSE')}diagnostic.resultCode=parsed.resultCode;diagnostic.responseStructure=parsed.structure;parsed.ok=parsed.ok&&diagnostic.httpStatus===200;
 // Only allowlisted official business fields leave the server. Never expose URLs containing keys or raw errors.
 for(const item of parsed.items)for(const field of Object.keys(item))if(typeof item[field]==='string'&&(item[field].includes(key)||item[field].includes(decoded)))item[field]='';
 result={status:parsed.ok?'ok':'unavailable',items:parsed.ok?parsed.items:[],totalCount:parsed.ok?parsed.totalCount:0,diagnostic,sourceUrl:service.sourceUrl,serviceName:service.name,fetchedAt:new Date().toISOString(),message:parsed.ok?'':'공공조달 정보를 현재 불러올 수 없습니다.',scope:'조회 기간 내 최대 100건입니다. 전체 업체·계약 목록이 아닙니다.'};
 }catch(e){diagnostic.failure=e?.name==='AbortError'?'TIMEOUT':diagnostic.httpStatus&&diagnostic.httpStatus!==200?'HTTP_ERROR':'NETWORK_OR_PARSE_ERROR';result={status:'unavailable',items:[],diagnostic,message:'공공조달 정보를 현재 불러올 수 없습니다.',sourceUrl:service.sourceUrl};}
 try{if(!env.PUBLIC_READ_ONLY)await env.DB.prepare('INSERT INTO procurement_cache (id,payload,fetched_at,diagnostic) VALUES (?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,fetched_at=excluded.fetched_at,diagnostic=excluded.diagnostic').bind(cacheKey,JSON.stringify(result),Date.now(),JSON.stringify(diagnostic)).run()}catch{}
 return result;
}
