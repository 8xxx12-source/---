// Public views are a projection of real, consented-public records, never an identity.
import {parseObject} from './analysis-service.js';
const pick=(v,keys)=>Object.fromEntries(keys.filter(k=>v?.[k]!==undefined).map(k=>[k,v[k]]));
export function publicComplaint(p){
 const out=pick(p,['id','region','district','neighborhood','location','category','description','danger','obstruction','priority','priority_reason','created','updated','status','source','visibility','estimate_low','estimate_high','estimate_basis','vendor','spent','resolution','evidence','assigned_organization','assigned_department','cancel_requested_at','revision','cluster_id','actionProposal','priorityMode','similarCount','mine']);
 const review=parseObject(p.assessment?.review||p.review);
 out.assessment={...p.assessment,review:pick(review,['emergency','verified','contextVerified','cityArea','dueAt','updatedAt','externalContext'])};
 out.external_context=p.external_context;
 out.similarReports=(p.similarReports||[]).map(x=>pick(x,['id','created','status']));
 return out;
}
export function publicAnalysis(v){
 const out=pick(v,['version','action','industryMatches','contracts','contractMatching','candidates','candidateScope','candidateLimit','cost','context','fetchedAt','cached']);
 out.sources=Object.fromEntries(Object.entries(v.sources||{}).filter(([,x])=>!Array.isArray(x)).map(([k,x])=>[k,{...pick(x,['status','serviceName','sourceUrl','fetchedAt']),diagnostic:pick(x.diagnostic,['httpStatus','resultCode'])}]));
 // Do not expose AI input envelopes, internal review notes or raw upstream payloads.
 return out;
}
export async function publicSanitizer(database,env){
 const accounts=(await database.prepare('SELECT id,username,nickname FROM users').all()).results;
 const secrets=Object.keys(env).filter(k=>/KEY|SECRET|PASSWORD|TOKEN/.test(k)).map(k=>env[k]).filter(x=>typeof x==='string'&&x.length>5);
 const identities=[...accounts.flatMap(x=>[x.id,x.username,x.nickname]),...secrets.flatMap(x=>{let decoded=x;try{decoded=decodeURIComponent(x)}catch{}return [x,decoded,encodeURIComponent(x)]})].filter(x=>x&&x.length>=2).sort((a,b)=>b.length-a.length);
 const scrub=s=>{for(const value of identities)s=s.split(value).join('[개인정보 비공개]');return s
 .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[이메일 비공개]')
 .replace(/(?:\+82[- .]?)?0?1[016789][- .]?\d{3,4}[- .]?\d{4}/g,'[연락처 비공개]')
 .replace(/\b\d{6}[- ]?[1-8]\d{6}\b/g,'[개인번호 비공개]')
 .replace(/(?:성명|이름|작성자|연락처|전화번호|아이디|계좌번호)\s*[:：=]\s*[^\s,;\n]+/g,'[개인정보 비공개]')
 .replace(/\b\d{2,3}\s?[가-힣]\s?\d{4}\b/g,'[차량번호 비공개]');};
 const hidden=new Set(['owner','user_id','username','nickname','email','password','password_hash','password_salt','actor','deleted_by','delete_reason','cancel_reason','memo','analysis_evidence','region_metadata','input','token','keyName','keyPresent']);
 const visit=(v,key='')=>typeof v==='string'?(key==='url'&&/^https?:\/\/place\.map\.kakao\.com\/\d+$/.test(v)?(secrets.some(s=>v.includes(s))?'':v):scrub(v)):Array.isArray(v)?v.map(x=>visit(x)):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).filter(([k])=>!hidden.has(k)).map(([k,x])=>[k,visit(x,k)])):v;
 return visit;
}
export function readOnlyEnvironment(env){
 return {...env,PUBLIC_READ_ONLY:true,DB:{prepare(query){if(!/^\s*SELECT\b/i.test(query))throw Error('Read-only database access');return env.DB.prepare(query)},batch(){throw Error('Read-only database access')}}};
}
const reads=new Map();
export async function cachedPublicRead(key,fetcher){
 const hit=reads.get(key);if(hit&&hit.until>Date.now())return hit.promise;
 if(reads.size>=100)reads.delete(reads.keys().next().value);
 const promise=Promise.resolve().then(fetcher);reads.set(key,{until:Date.now()+300000,promise});
 try{return await promise}catch(e){reads.delete(key);throw e}
}
