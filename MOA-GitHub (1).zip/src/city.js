import {XMLParser,XMLValidator} from 'fast-xml-parser';
import catalog from './city-places.json' with {type:'json'};
export const CITY_AREAS=catalog.places.map(p=>p.name);
const SOURCE_URL='https://data.seoul.go.kr/dataList/OA-21285/A/1/datasetView.do';
const arr=v=>v==null||v===''?[]:Array.isArray(v)?v:[v];
const txt=v=>typeof v==='string'||typeof v==='number'?String(v).trim().slice(0,1200):null;
const num=v=>v!==''&&v!=null&&Number.isFinite(Number(v))?Number(v):null;
const first=(o,k)=>arr(o?.[k]?.[k]??o?.[k])[0]||{};
const cityError=code=>Object.assign(new Error('city upstream unavailable'),{safeCode:code});
export function parseCity(xml,expected){
 if(xml.length>3000000||/<!DOCTYPE|<!ENTITY/i.test(xml)||XMLValidator.validate(xml)!==true)throw cityError('INVALID_XML');
 const doc=new XMLParser({parseTagValue:false,ignoreAttributes:true,processEntities:false}).parse(xml),root=doc['SeoulRtd.citydata'];
 const code=root?.RESULT?.['RESULT.CODE']||doc.RESULT?.CODE;
 if(code!=='INFO-000'||!root?.CITYDATA)throw cityError(/^(INFO|ERROR)-[0-9]{3}$/.test(code)?code:'INVALID_RESPONSE');const c=root.CITYDATA;
 if(c.AREA_NM!==expected)throw cityError('AREA_MISMATCH');
 const p=first(c,'LIVE_PPLTN_STTS'),road=c.ROAD_TRAFFIC_STTS?.AVG_ROAD_DATA||{},weather=first(c,'WEATHER_STTS');
 const incidents=arr(c.ACDNT_CNTRL_STTS?.ACDNT_CNTRL_STTS).filter(x=>x&&x.ACDNT_INFO).map(x=>({type:txt(x.ACDNT_TYPE),detail:txt(x.ACDNT_INFO),occurredAt:txt(x.ACDNT_OCCR_DT),expectedEnd:txt(x.EXP_CLR_DT),updatedAt:txt(x.ACDNT_TIME),longitude:num(x.ACDNT_X),latitude:num(x.ACDNT_Y)}));
 const stations=arr(c.SUB_STTS?.SUB_STTS).filter(x=>x?.SUB_STN_NM).map(x=>({name:txt(x.SUB_STN_NM),line:txt(x.SUB_STN_LINE)}));
 const population=txt(p.AREA_CONGEST_LVL)?{level:txt(p.AREA_CONGEST_LVL),min:num(p.AREA_PPLTN_MIN),max:num(p.AREA_PPLTN_MAX),updatedAt:txt(p.PPLTN_TIME),forecast:p.FCST_YN==='Y'?arr(p.FCST_PPLTN?.FCST_PPLTN).filter(x=>x?.FCST_TIME).map(x=>({time:txt(x.FCST_TIME),level:txt(x.FCST_CONGEST_LVL),min:num(x.FCST_PPLTN_MIN),max:num(x.FCST_PPLTN_MAX)})):[]}:null;
 const traffic=txt(road.ROAD_TRAFFIC_IDX)?{level:txt(road.ROAD_TRAFFIC_IDX),speed:num(road.ROAD_TRAFFIC_SPD),updatedAt:txt(road.ROAD_TRAFFIC_TIME)}:null;
 const climate=num(weather.TEMP)!==null?{temperature:num(weather.TEMP),precipitation:txt(weather.PRECPT_TYPE),updatedAt:txt(weather.WEATHER_TIME)}:null;
 if(!population&&!traffic&&!climate)throw cityError('MISSING_FIELDS');
 return {source:'SEOUL_CITYDATA',sourceUrl:SOURCE_URL,license:'공공누리 1유형 · 서울특별시',area:txt(c.AREA_NM),areaCode:txt(c.AREA_CD),population,traffic,weather:climate,incidents:c.ACDNT_CNTRL_STTS!==undefined?incidents:null,stations,sourceTimes:[population?.updatedAt,traffic?.updatedAt,climate?.updatedAt,...incidents.map(i=>i.updatedAt)].filter(Boolean)};
}
export async function cityStatus(env,area){
 if(!CITY_AREAS.includes(area))return {status:'invalid_area',message:'지원하는 장소를 선택해주세요.'};
 if(!env.SEOUL_API_KEY)return {status:'not_configured',message:'서울시 데이터 연결을 준비 중입니다.'};
 const database=env.DB,now=Date.now();let cached;const diagnostic={keyPresent:true,stage:'cache',httpStatus:null,resultCode:null,responseBytes:0,format:null,failure:null,keyWhitespaceTrimmed:env.SEOUL_API_KEY!==env.SEOUL_API_KEY.trim(),redirectErrorModeSupported:true};
 // Compatibility probe constructs a key-free request; it makes no network call.
 try{new Request('http://openapi.seoul.go.kr:8088/',{redirect:'error'})}catch{diagnostic.redirectErrorModeSupported=false}
 try{
  if(!env.PUBLIC_READ_ONLY)await database.prepare('INSERT OR IGNORE INTO city_cache (area,retry_after) VALUES (?,0)').bind(area).run();cached=await database.prepare('SELECT * FROM city_cache WHERE area=?').bind(area).first();
  if(cached?.payload&&now-cached.fetched_at<300000){let prior;try{prior=JSON.parse(cached.last_error)}catch{}if(!env.PUBLIC_READ_ONLY&&prior?.stage==='complete')await database.prepare('UPDATE city_cache SET last_error=? WHERE area=?').bind(JSON.stringify({...prior,keyWhitespaceTrimmed:diagnostic.keyWhitespaceTrimmed,redirectErrorModeSupported:diagnostic.redirectErrorModeSupported}),area).run();return {status:'ok',cached:true,fetchedAt:new Date(cached.fetched_at).toISOString(),data:JSON.parse(cached.payload)}};
  const lock=env.PUBLIC_READ_ONLY?{meta:{changes:1}}:await database.prepare('UPDATE city_cache SET retry_after=? WHERE area=? AND retry_after<=?').bind(now+30000,area,now).run();
  if(!lock.meta.changes)return cached?.payload?{status:'stale',message:'서울시 데이터를 갱신 중입니다. 이전 수신 자료입니다.',fetchedAt:new Date(cached.fetched_at).toISOString(),data:JSON.parse(cached.payload)}:{status:'unavailable',message:'서울시 데이터를 일시적으로 불러올 수 없습니다.'};
  diagnostic.stage='fetch';const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);let xml;
  try{const response=await fetch('http://openapi.seoul.go.kr:8088/'+encodeURIComponent(env.SEOUL_API_KEY.trim())+'/xml/citydata/1/5/'+encodeURIComponent(area),{signal:controller.signal,redirect:'manual'});diagnostic.httpStatus=response.status;diagnostic.stage='read';if(!response.ok)throw cityError('HTTP_'+response.status);const reader=response.body.getReader();let chunks=[],size=0;while(true){const {value,done}=await reader.read();if(done)break;size+=value.length;if(size>3000000){await reader.cancel();throw cityError('OVERSIZE')}chunks.push(value)}const merged=new Uint8Array(size);let offset=0;for(const b of chunks){merged.set(b,offset);offset+=b.length}xml=new TextDecoder().decode(merged);diagnostic.responseBytes=size;diagnostic.format=/^\s*<(!doctype\s+html|html)/i.test(xml)?'html':/^\s*[{[]/.test(xml)?'json':/^\s*</.test(xml)?'xml':'other';const match=xml.match(/<(?:RESULT\.)?CODE>\s*((?:INFO|ERROR)-[0-9]{3})\s*</);diagnostic.resultCode=match?.[1]||null}finally{clearTimeout(timer)}
  diagnostic.stage='parse';const data=parseCity(xml,area),fetched=Date.now();diagnostic.stage='save';if(!env.PUBLIC_READ_ONLY)await database.prepare('UPDATE city_cache SET payload=?,fetched_at=?,retry_after=0,last_error=?,last_attempt_at=? WHERE area=?').bind(JSON.stringify(data),fetched,JSON.stringify({...diagnostic,stage:'complete',failure:null}),fetched,area).run();return {status:'ok',cached:false,fetchedAt:new Date(fetched).toISOString(),data,diagnostic:{...diagnostic,stage:'complete'}};
 }catch(error){
  const allowed=/^(INFO|ERROR)-[0-9]{3}$|^HTTP_[0-9]{3}$|^(INVALID_RESPONSE|AREA_MISMATCH|INVALID_XML|MISSING_FIELDS|OVERSIZE)$/;
  const message=String(error?.message||'');
  const cause=error?.name==='AbortError'?'TIMEOUT':/redirect/i.test(message)?'REDIRECT_REJECTED':/https/i.test(message)&&/only|require|support|allow/i.test(message)?'HTTPS_REQUIRED':/port/i.test(message)?'PORT_REJECTED':/blocked|denied|disallow|forbidden/i.test(message)?'REQUEST_BLOCKED':/dns|resolve|lookup/i.test(message)?'DNS_FAILURE':/fetch|network|connect/i.test(message)?'NETWORK_FAILURE':'RUNTIME_FAILURE';
  diagnostic.failure=allowed.test(error?.safeCode||'')?error.safeCode:cause;
  diagnostic.errorType=['TypeError','Error','RangeError','ReferenceError','AbortError'].includes(error?.name)?error.name:'Other';
  try{if(!env.PUBLIC_READ_ONLY)await database.prepare('UPDATE city_cache SET last_error=?,last_attempt_at=? WHERE area=?').bind(JSON.stringify(diagnostic),Date.now(),area).run()}catch{}
  // Never return/log the upstream URL or exception: it contains the server key.
  if(cached?.payload)return {status:'stale',message:'서울시 데이터를 일시적으로 불러올 수 없습니다. 이전 수신 자료입니다.',fetchedAt:new Date(cached.fetched_at).toISOString(),data:JSON.parse(cached.payload)};
  return {status:'unavailable',message:'서울시 데이터를 일시적으로 불러올 수 없습니다.',diagnostic};
 }
}
