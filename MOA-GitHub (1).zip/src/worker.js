import {districtStats,periodWindow} from './district-stats.js';
import {WORK_TASKS,proposeAction} from './actions.js';
import {localVendors} from './local-vendors.js';
import {publicSanitizer,publicComplaint,publicAnalysis,readOnlyEnvironment,cachedPublicRead} from './public-access.js';
import {resolutionAnalysis} from './resolution.js';
import {parseObject} from './analysis-service.js';
import {procurement,services} from './procurement.js';
import {clusterKey,assess,decorate,normalizeLocation,ANALYSIS_VERSION,compareWork} from './assessment.js';
import {cityStatus,CITY_AREAS} from './city.js';
const REGIONS=__REGIONS__;
const CATALOG=__CATALOG__;
const PAGE=__PAGE__,STYLE=__STYLE__,CLIENT=__CLIENT__;
const json=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status})};
function str(v,max,min=1){if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)fail('입력 내용을 확인해주세요.');return v.trim()}
function amount(v){if(v===null||v===''||v===undefined)return null;if(!Number.isSafeInteger(v)||v<0||v>100000000000)fail('금액은 0 이상의 원 단위 정수로 입력해주세요.');return v}
const categories=['보도블록·보행로','도로 파손','배수·물고임','안전시설','기타 도로 불편','보도·보행','교통신호','불법주정차','가로등','쓰레기·환경','시설물 파손','대중교통','안전 위험','소음','기타'];
const statuses=['접수','확인 중','처리 중','해결 완료','제외'];
const hex=b=>Array.from(new Uint8Array(b),v=>v.toString(16).padStart(2,'0')).join('');
const bytes=h=>Uint8Array.from(h.match(/.{2}/g)||[],x=>parseInt(x,16));
const digest=async s=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
const SESSION_COOKIE='__Host-moa_session_v2';
const SESSION_ATTRIBUTES='Path=/; HttpOnly; Secure; SameSite=None; Partitioned';
function cookieTokens(req){const pairs=(req.headers.get('cookie')||'').split(';').map(x=>x.trim().split('='));return [...new Set([SESSION_COOKIE,'__Host-moa_session'].flatMap(name=>pairs.filter(([k,v])=>k===name&&/^[a-f0-9]{64}$/.test(v||'')).map(([,v])=>v)))];}
function clearSessionCookies(r){r.headers.append('Set-Cookie',`${SESSION_COOKIE}=; ${SESSION_ATTRIBUTES}; Max-Age=0`);r.headers.append('Set-Cookie','__Host-moa_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');}
const ITERATIONS=100000;
const safeUser=u=>({id:u.id,username:u.username,nickname:u.nickname,role:u.role,admin:u.role==='ADMIN'||u.role==='STAFF'});
async function passwordHash(password,salt,iterations=ITERATIONS){const m=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes(salt),iterations,hash:'SHA-256'},m,256))}
function equalHash(a,b){let bad=a.length^b.length;for(let i=0;i<a.length;i++)bad|=a.charCodeAt(i)^b.charCodeAt(i);return bad===0}
function username(v){const name=str(v,100,3).toLowerCase();if(!/^[a-z0-9][a-z0-9._@+-]{2,99}$/.test(name))fail('아이디는 영문·숫자로 시작하는 3~100자 또는 이메일을 입력해주세요.');return name}
async function limit(database,key,max){const window=Math.floor(Date.now()/900000);await database.prepare('DELETE FROM login_attempts WHERE window < ?').bind(window-1).run();await database.prepare('INSERT INTO login_attempts (id, window, attempts) VALUES (?, ?, 1) ON CONFLICT(id) DO UPDATE SET attempts=CASE WHEN window=excluded.window THEN attempts+1 ELSE 1 END, window=excluded.window').bind(key,window).run();const row=await database.prepare('SELECT attempts FROM login_attempts WHERE id = ?').bind(key).first();if(row.attempts>max)fail('시도가 많습니다. 15분 후 다시 시도해주세요.',429)}
async function identity(req,env,optional=false){for(const token of cookieTokens(req)){const s=await db(env).prepare('SELECT expires,user_id FROM sessions WHERE token = ?').bind(await digest(token)).first();if(s&&s.expires>Date.now()){
 if(s.user_id){const u=await db(env).prepare('SELECT id,username,nickname,role FROM users WHERE id = ?').bind(s.user_id).first();if(u)return safeUser(u)}
 // Only legacy session rows have a null user_id. New sessions always bind a user.
 else {const u=await db(env).prepare('SELECT id,username,nickname,role FROM users WHERE id=?').bind('moa-single-admin').first();if(u)return safeUser(u)};
 }}if(optional)return null;fail('로그인 후 이용해주세요.',401)}
async function sessionResponse(req,database,user,status=200){const token=hex(crypto.getRandomValues(new Uint8Array(32)));const queries=[database.prepare('DELETE FROM sessions WHERE expires <= ?').bind(Date.now())];for(const old of cookieTokens(req))queries.push(database.prepare('DELETE FROM sessions WHERE token = ?').bind(await digest(old)));queries.push(database.prepare('INSERT INTO sessions (token, expires, user_id) VALUES (?, ?, ?)').bind(await digest(token),Date.now()+86400000,user.id));await database.batch(queries);const r=json({authenticated:true,user:safeUser(user)},status);r.headers.append('Set-Cookie',`${SESSION_COOKIE}=${token}; ${SESSION_ATTRIBUTES}; Max-Age=86400`);r.headers.append('Set-Cookie','__Host-moa_session=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0');return r}
async function auth(req,env,url){const database=db(env);if(req.method==='POST'&&req.headers.get('origin')!==url.origin)fail('허용되지 않은 요청입니다.',403);
 if(url.pathname==='/api/auth/me'&&req.method==='GET'){const user=await identity(req,env,true);return json({authenticated:!!user,user})}
 if(url.pathname==='/api/auth/logout'&&req.method==='POST'){for(const token of cookieTokens(req))await database.prepare('DELETE FROM sessions WHERE token = ?').bind(await digest(token)).run();const r=json({ok:true});clearSessionCookies(r);return r}
 if(req.method!=='POST'||!['/api/auth/register','/api/auth/login'].includes(url.pathname))fail('요청한 기능을 찾을 수 없습니다.',404);
 const b=await body(req),name=username(b.username),register=url.pathname.endsWith('/register');
 if(typeof b.password!=='string'||b.password.length>128||b.password.length<1)fail('비밀번호를 확인해주세요.');
 const ipKey=await digest(req.headers.get('CF-Connecting-IP')||'unknown-client');await limit(database,(register?'signup:':'login-ip:')+ipKey,register?5:60);
 if(register){if(b.password.length<12)fail('비밀번호는 12자 이상으로 입력해주세요.');if(b.password!==b.passwordConfirm)fail('비밀번호 확인이 일치하지 않습니다.');const nickname=str(b.nickname,24,2);if(/[\x00-\x1f<>]/.test(nickname))fail('닉네임을 확인해주세요.');
 if(name===env.MOA_LOGIN_USERNAME?.toLowerCase()||await database.prepare('SELECT id FROM users WHERE username = ?').bind(name).first())fail('이미 사용 중인 아이디입니다.',409);
 const user={id:crypto.randomUUID(),username:name,nickname,role:'USER'},salt=hex(crypto.getRandomValues(new Uint8Array(24))),hash=await passwordHash(b.password,salt);
 try{await database.prepare('INSERT INTO users (id,username,nickname,password_hash,password_salt,password_iterations,role,created) VALUES (?,?,?,?,?,?,?,?)').bind(user.id,name,nickname,hash,salt,ITERATIONS,'USER',new Date().toISOString()).run()}catch(e){if(String(e.message).includes('UNIQUE'))fail('이미 사용 중인 아이디입니다.',409);throw e}return sessionResponse(req,database,user,201);
 }
 const accountKey='login-account:'+await digest(name);await limit(database,accountKey,10);
 let user=await database.prepare('SELECT * FROM users WHERE username = ?').bind(name).first();
 const legacy=!user&&name===env.MOA_LOGIN_USERNAME?.toLowerCase()&&env.MOA_PASSWORD_HASH&&env.MOA_PASSWORD_SALT;
 const salt=user?.password_salt||(legacy?env.MOA_PASSWORD_SALT:'000000000000000000000000000000000000000000000000'),expected=user?.password_hash||(legacy?env.MOA_PASSWORD_HASH:'0'.repeat(64));
 const result=await passwordHash(b.password,salt,user?.password_iterations||ITERATIONS);
 if(!equalHash(result,expected)||(!user&&!legacy))fail('아이디 또는 비밀번호가 맞지 않습니다.',401);
 if(legacy){user={id:'moa-single-admin',username:name,nickname:'MOA 운영자',role:'ADMIN'};await database.prepare('INSERT OR IGNORE INTO users (id,username,nickname,password_hash,password_salt,password_iterations,role,created) VALUES (?,?,?,?,?,?,?,?)').bind(user.id,name,user.nickname,env.MOA_PASSWORD_HASH,env.MOA_PASSWORD_SALT,ITERATIONS,'ADMIN',new Date().toISOString()).run();user=await database.prepare('SELECT * FROM users WHERE id = ?').bind(user.id).first()}
 await database.prepare('DELETE FROM login_attempts WHERE id = ?').bind(accountKey).run();return sessionResponse(req,database,user);
}

function db(env){if(!env.DB)fail('저장소 연결을 준비 중입니다. 잠시 후 다시 시도해주세요.',503);return env.DB}
function issueGroup(p){return JSON.stringify([p.region,p.district,p.neighborhood,p.category,p.source,normalizeLocation(p.location),proposeAction(p).taskId]);}
function decorateGroup(p,group){const peers=group.map(q=>({...q,cluster_id:p.cluster_id}));return {...decorate(p,peers),similarReports:peers.map(q=>({id:q.id,created:q.created,status:q.status,location:q.location}))};}
function adminDecorate(p,rows){const key=issueGroup(p);return decorateGroup(p,rows.filter(q=>issueGroup(q)===key));}
function rankRows(rows){const groups=new Map();for(const p of rows){const key=issueGroup(p);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(p);}return rows.map(p=>decorateGroup(p,groups.get(issueGroup(p)))).sort(compareWork);}
async function analyzed(database,p,all=false){if(!p)return p;const peers=(await database.prepare(all?'SELECT * FROM complaints WHERE district=? AND category=? AND deleted_at IS NULL':'SELECT * FROM complaints WHERE cluster_id=? AND deleted_at IS NULL').bind(...(all?[p.district,p.category]:[p.cluster_id])).all()).results;return all?adminDecorate(p,peers):decorate(p,peers)}

const publicRow=(p,user)=>{if(!p)return null;const {owner,deleted_by,delete_reason,review,...rest}=p;if(!user?.admin&&rest.assessment){const {review:r,...safe}=rest.assessment;rest.assessment=safe;}return {...rest,...(user?.admin?{review}:{}),mine:!!user&&owner===user.id}};
async function body(req){if(Number(req.headers.get('content-length'))>24000)fail('입력 내용이 너무 깁니다.',413);const raw=await req.text();if(raw.length>24000)fail('입력 내용이 너무 깁니다.',413);try{return JSON.parse(raw)}catch{fail('입력 형식을 확인해주세요.')}}
async function api(req,env,url,ctx){const user=await identity(req,env,req.method==='GET'),database=db(env);if(req.method!=='GET'){const origin=req.headers.get('origin');if(origin!==url.origin)fail('허용되지 않은 요청입니다.',403)}
 if(url.pathname==='/api/admin/district-stats'&&req.method==='GET'){
 if(!user?.admin)fail('행정업무 권한이 필요합니다.',user?403:401);
 const period=url.searchParams.get('period')||'30';if(!['7','30','3m'].includes(period))fail('기간을 확인해주세요.');
 const now=Date.now(),w=periodWindow(period,now);const rows=await database.prepare("SELECT region,district,created FROM complaints WHERE deleted_at IS NULL AND status <> '제외' AND (source='MOA' OR source IS NULL) AND created >= ?").bind(new Date(w.previousStart).toISOString()).all();
 return json(districtStats(rows.results,Object.keys(REGIONS),period,now));
 }
 if(url.pathname.startsWith('/api/admin/')){
 if(req.method!=='GET'&&!user?.admin)fail('행정업무 권한이 필요합니다.',user?403:401);
 const route=url.pathname.match(/^\/api\/admin\/complaints\/([a-f0-9-]{36})\/(review|analysis|local-vendors|work-plan|priority)$/);
 if(!route)fail('요청한 기능을 찾을 수 없습니다.',404);
 const p=await database.prepare('SELECT * FROM complaints WHERE id=? AND deleted_at IS NULL').bind(route[1]).first();if(!p||(!user?.admin&&p.visibility!=='public'&&p.owner!==user?.id))fail('민원을 찾을 수 없습니다.',404);
 if(route[2]==='local-vendors'&&req.method==='GET'){const clean=await publicSanitizer(database,env);return json(clean(await localVendors(env,clean({id:p.id,revision:p.revision,region:p.region,district:p.district,location:p.location,category:p.category,description:p.description,review:{workPlan:parseObject(p.review).workPlan}}))));}
 if(route[2]==='analysis'&&req.method==='GET'){if(user?.admin)return json(await resolutionAnalysis(env,await analyzed(database,p,true)));const clean=await publicSanitizer(database,env);return json(clean(publicAnalysis(await cachedPublicRead('resolution:'+p.id+':'+p.revision,async()=>resolutionAnalysis(readOnlyEnvironment(env),await analyzed(database,p,false))))));}
 if(['work-plan','priority'].includes(route[2])&&req.method==='PATCH'){
 const b=await body(req);if(b.revision!==p.revision)fail('다른 변경이 먼저 저장됐습니다. 다시 열어주세요.',409);const reason=str(b.reason,500,5),before=parseObject(p.review),now=new Date().toISOString();let change;
 if(route[2]==='work-plan'){if(!WORK_TASKS.some(t=>t.id===b.taskId))fail('필요 작업을 선택해주세요.');if(!Array.isArray(b.keywords)||b.keywords.length<1||b.keywords.length>4)fail('검색어를 1~4개 입력해주세요.');change={workPlan:{taskId:b.taskId,keywords:b.keywords.map(k=>str(k,40,2)),reason,actor:user.id,updatedAt:now}};}
 else{if(!Number.isInteger(b.score)||b.score<0||b.score>100)fail('점수는 0~100 사이로 입력해주세요.');change={priorityOverride:{score:b.score,reason,actor:user.id,updatedAt:now}};}
 const after={...before,...change};const result=await database.batch([database.prepare('INSERT INTO events (id,complaint_id,action,detail,actor,created) SELECT ?,id,?,?,?,? FROM complaints WHERE id=? AND revision=?').bind(crypto.randomUUID(),route[2]==='priority'?'우선처리 순서 변경':'업체 검색 기준 변경',JSON.stringify({before:route[2]==='priority'?before.priorityOverride||{score:(await analyzed(database,p,true)).assessment.workScore,version:ANALYSIS_VERSION}:before.workPlan||null,after:change,reason}),user.nickname+' ['+user.id+']',now,p.id,p.revision),database.prepare('UPDATE complaints SET review=?,updated=?,revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(after),now,p.id,p.revision)]);if(!result[1].meta.changes)fail('다른 변경이 먼저 저장됐습니다.',409);return json({saved:true});
 }
 if(route[2]==='review'&&req.method==='PATCH'){
 const b=await body(req);if(b.revision!==p.revision)fail('다른 변경이 먼저 저장됐습니다. 다시 열어주세요.',409);
 if(!['긴급 지정','현장 확인','일반 처리','미검토'].includes(b.emergency))fail('검토 구분을 확인해주세요.');
 const memo=str(b.memo,1500,5),dueAt=b.dueAt||null;if(dueAt&&(!/^\d{4}-\d{2}-\d{2}T/.test(dueAt)||!Number.isFinite(Date.parse(dueAt))))fail('기한을 확인해주세요.');
 let selectedContext=null;if(b.cityArea){if(!CITY_AREAS.includes(b.cityArea))fail('공식 서울시 장소를 선택해주세요.');try{const c=await cityStatus(env,b.cityArea);if(c.data)selectedContext={association:'admin_selected_context',fetchedAt:c.fetchedAt,data:c.data};}catch{}}
 const now=new Date().toISOString(),before=parseObject(p.review),after={...before,facilityVerified:b.facilityVerified===true,externalContext:selectedContext||before.externalContext||null,cityArea:b.cityArea||before.cityArea||null,emergency:b.emergency,memo,dueAt,verified:b.verified===true,contextVerified:b.contextVerified===true,actor:user.id,updatedAt:now};
 const result=await database.batch([database.prepare('INSERT INTO events (id,complaint_id,action,detail,actor,created) SELECT ?,id,?,?,?,? FROM complaints WHERE id=? AND revision=?').bind(crypto.randomUUID(),'관리자 검토',JSON.stringify({before:{...before,externalContext:before.externalContext?{area:before.externalContext.data?.area,fetchedAt:before.externalContext.fetchedAt}:null},after:{...after,externalContext:after.externalContext?{area:after.externalContext.data?.area,fetchedAt:after.externalContext.fetchedAt}:null}}),user.nickname+' ['+user.id+']',now,p.id,p.revision),database.prepare('UPDATE complaints SET review=?,updated=?,revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(after),now,p.id,p.revision)]);if(!result[1].meta.changes)fail('다른 변경이 먼저 저장됐습니다.',409);return json({saved:true});
 }fail('요청한 기능을 찾을 수 없습니다.',404);
 }
 if(url.pathname==='/api/procurement'&&req.method==='GET'){
 if(user?.admin)await limit(database,'procurement:'+await digest(req.headers.get('CF-Connecting-IP')||'unknown-client'),30);
 const kind=url.searchParams.get('kind');if(!Object.hasOwn(services,kind))fail('지원하지 않는 조회입니다.');
 const district=url.searchParams.get('district')||'송파구';if(!REGIONS[district])fail('서울 자치구를 선택해주세요.');
 const term=(url.searchParams.get('term')||'').trim();if(term.length>50)fail('검색어는 50자 이하로 입력해주세요.');
 const bizno=url.searchParams.get('bizno')||'';if(kind==='vendorIndustries'&&!/^[0-9]{10}$/.test(bizno))fail('업체 등록번호를 확인해주세요.');
 const workType=['goods','service','construction'].includes(url.searchParams.get('workType'))?url.searchParams.get('workType'):'construction';const query={district,term,bizno,workType};if(user?.admin)return json(await procurement(env,kind,query));const clean=await publicSanitizer(database,env);return json(clean(await cachedPublicRead('resource:'+kind+JSON.stringify(query),()=>procurement(readOnlyEnvironment(env),kind,query))));
 }
 if(url.pathname==='/api/complaints'&&req.method==='GET'){const mine=url.searchParams.get('mine')==='1';if(mine&&!user)fail('로그인 후 이용해주세요.',401);const rows=await database.prepare(mine?'SELECT * FROM complaints WHERE deleted_at IS NULL AND owner = ? ORDER BY priority DESC, created ASC':user?.admin?'SELECT * FROM complaints WHERE deleted_at IS NULL ORDER BY priority DESC, created ASC':'SELECT * FROM complaints WHERE deleted_at IS NULL AND (visibility = \'public\' OR owner = ?) ORDER BY priority DESC, created ASC').bind(...(mine?[user.id]:user?.admin?[]:[user?.id||''])).all();const clean=user?.admin?x=>x:await publicSanitizer(database,env);const ranked=rankRows(rows.results);return json({items:ranked.map(p=>user?.admin?publicRow(p,user):clean(publicComplaint({...publicRow(p,user),assessment:p.assessment}))),admin:!!user?.admin,assessment:ANALYSIS_VERSION});}
 if(url.pathname==='/api/complaints'&&req.method==='POST'){
 const b=await body(req),id=str(b.id,50);if(!/^[a-f0-9-]{36}$/.test(id))fail('등록 번호를 다시 생성해주세요.');
 const existing=await database.prepare('SELECT * FROM complaints WHERE id = ?').bind(id).first();if(existing){if(existing.deleted_at)fail('삭제된 등록 번호입니다.',409);if(existing.owner!==user.id)fail('중복 등록 번호입니다.',409);return json({item:publicRow(existing,user)});}
 const region=str(b.region,40),district=str(b.district,40),neighborhood=str(b.neighborhood,40),location=str(b.location,200),description=str(b.description,2000,5),category=str(b.category,40);
 if(region!=='서울특별시'||!REGIONS[district]?.includes(neighborhood))fail('서울특별시의 구와 동을 선택해주세요.');
 if(!categories.includes(category)||typeof b.danger!=='boolean'||typeof b.obstruction!=='boolean')fail('문제 유형과 위험 여부를 확인해주세요.');
 const now=new Date().toISOString();
 const harm=b.harmLevel??0,impact=b.lifeImpact??(b.obstruction?1:0);
 if(![0,1,2,3].includes(harm)||![0,1,2].includes(impact))fail('피해와 생활 영향을 확인해주세요.');
 const facts=b.impactFacts||{};if(![0,1,2,3].includes(facts.affected??0)||![true,false,undefined].includes(facts.vulnerable)||![true,false,undefined].includes(facts.escalation))fail('영향 정보를 확인해주세요.');
 const impactFacts=JSON.stringify({affected:facts.affected??0,vulnerable:facts.vulnerable===true,escalation:facts.escalation===true,verification:'reporter_claim'});
 const candidate={impact_facts:impactFacts,id,region,district,neighborhood,location,category,owner:user.id,source:'MOA',visibility:b.visibility==='public'?'public':'private',danger:Number(b.danger),obstruction:Number(b.obstruction),harm_level:harm,life_impact:impact,created:now,status:'접수'};
 candidate.cluster_id=await clusterKey(candidate);
 const peers=(await database.prepare('SELECT * FROM complaints WHERE cluster_id=? AND deleted_at IS NULL').bind(candidate.cluster_id).all()).results;
 const assessment=assess(candidate,[...peers,candidate]),priority=assessment.priority,reason=assessment.reasons.join(' ');
 let externalContext=null;if(b.cityArea&&CITY_AREAS.includes(b.cityArea)){try{const cached=await database.prepare('SELECT payload,fetched_at FROM city_cache WHERE area=?').bind(b.cityArea).first();if(cached?.payload&&Date.now()-cached.fetched_at<900000)externalContext=JSON.stringify({association:'user_selected_context_not_verified_location',capturedAt:new Date().toISOString(),fetchedAt:new Date(cached.fetched_at).toISOString(),data:JSON.parse(cached.payload)})}catch{}}
 const regionMetadata=JSON.stringify({provinceCode:CATALOG.provinces[0].id,districtCode:CATALOG.provinces[0].districts.find(d=>d.name===district).id,neighborhoodSources:CATALOG.provinces[0].districts.find(d=>d.name===district).neighborhoods.find(n=>n.name===neighborhood).sources,catalogDate:CATALOG.effectiveDate});
 await database.batch([database.prepare('INSERT INTO complaints (id, region, district, neighborhood, location, category, description, danger, obstruction, priority, priority_reason, owner, created, updated, region_metadata,visibility,external_context,cluster_id,harm_level,life_impact,safety_risk,analysis_status,analysis_version,analysis_evidence,impact_facts) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?,?,?,?,?)').bind(id,region,district,neighborhood,location,category,description,Number(b.danger),Number(b.obstruction),priority,reason,user.id,now,now,regionMetadata,candidate.visibility,externalContext,candidate.cluster_id,harm,impact,Number(b.danger),'rules',ANALYSIS_VERSION,JSON.stringify(assessment),impactFacts),database.prepare('INSERT INTO events (id, complaint_id, action, detail, actor, created) VALUES (?, ?, ?, ?, ?, ?)').bind(crypto.randomUUID(),id,'민원 등록','현장 민원 등록. 자동 검토: '+reason,'등록자',now)]);
 const saved=await analyzed(database,await database.prepare('SELECT * FROM complaints WHERE id = ?').bind(id).first());if(ctx?.waitUntil)ctx.waitUntil(resolutionAnalysis(env,saved).catch(()=>{}));return json({item:publicRow(saved,user)},201);
 }
 const match=url.pathname.match(/^\/api\/complaints\/([a-f0-9-]{36})$/);if(match){const id=match[1],p=await database.prepare('SELECT * FROM complaints WHERE id = ?').bind(id).first();if(!p||p.deleted_at||(!user?.admin&&p.visibility!=='public'&&p.owner!==user?.id))fail('민원을 찾을 수 없습니다.',404);
 if(req.method==='GET'){const events=await database.prepare('SELECT action, detail, actor, created FROM events WHERE complaint_id = ? ORDER BY created ASC').bind(id).all();const clean=user?.admin?x=>x:await publicSanitizer(database,env);const decorated=await analyzed(database,p,!!user?.admin);return json({item:user?.admin?publicRow(decorated,user):clean(publicComplaint({...publicRow(decorated,user),assessment:decorated.assessment})),events:user?.admin?events.results:events.results.map(e=>({action:e.action,detail:e.action==='관리자 검토'?'관리자 검토 기록 · 내부 메모 비공개':e.action==='민원 등록'?'민원이 등록되었습니다.':'처리 기록이 변경되었습니다. 현재 상태와 처리 내용은 위에서 확인할 수 있습니다.',actor:e.action==='민원 등록'?'등록자':'운영자',created:e.created})),admin:!!user?.admin})}

 if(req.method==='DELETE'){
 if(p.owner!==user.id)fail('본인이 등록한 민원만 삭제 또는 취소 요청할 수 있습니다.',403);
 const b=await body(req);if(b.revision!==p.revision)fail('변경된 내역이 있습니다. 다시 열어 확인해주세요.',409);
 if(['해결 완료','제외'].includes(p.status))fail('처리가 종료된 민원은 삭제하거나 취소할 수 없습니다.',409);
 const reason=b.reason?str(b.reason,500):'작성자 요청',now=new Date().toISOString();
 const started=await database.prepare("SELECT id FROM events WHERE complaint_id=? AND action='처리 내역 변경' LIMIT 1").bind(id).first();
 const removable=p.status==='접수'&&!p.review&&!started&&!p.assigned_organization&&!p.assigned_department&&!p.vendor;
 if(!removable&&p.cancel_requested_at)return json({action:'cancel_requested',saved:true});
 const action=removable?'작성자 삭제':'접수 취소 요청';
 const update=removable?database.prepare('UPDATE complaints SET deleted_at=?,deleted_by=?,delete_reason=?,updated=?,revision=revision+1 WHERE id=? AND owner=? AND revision=? AND deleted_at IS NULL').bind(now,user.id,reason,now,id,user.id,p.revision):database.prepare('UPDATE complaints SET cancel_requested_at=?,cancel_reason=?,updated=?,revision=revision+1 WHERE id=? AND owner=? AND revision=? AND deleted_at IS NULL').bind(now,reason,now,id,user.id,p.revision);
 const result=await database.batch([database.prepare('INSERT INTO events (id,complaint_id,action,detail,actor,created) SELECT ?,id,?,?,?,? FROM complaints WHERE id=? AND owner=? AND revision=? AND deleted_at IS NULL').bind(crypto.randomUUID(),action,reason,'등록자',now,id,user.id,p.revision),update]);
 if(!result[1].meta.changes)fail('다른 변경이 먼저 저장됐습니다. 다시 확인해주세요.',409);
 return json({saved:true,action:removable?'deleted':'cancel_requested'});
 }
 if(req.method==='PATCH'){if(!user.admin)fail('운영자만 처리 내역을 수정할 수 있습니다.',403);const b=await body(req);if(!Number.isInteger(b.revision)||b.revision!==p.revision)fail('다른 변경이 먼저 저장됐습니다. 새로 열어 확인해주세요.',409);
 const status=str(b.status,20),priority=b.priority;if(!statuses.includes(status)||![1,2,3].includes(priority))fail('상태와 우선순위를 확인해주세요.');const reason=str(b.reason,1000,5),priorityReason=str(b.priorityReason,1000,5),low=amount(b.estimateLow),high=amount(b.estimateHigh),spent=amount(b.spent);
 if((low===null)!==(high===null)||low!==null&&low>high)fail('예상 예산의 최소·최대 금액을 확인해주세요.');
 const basis=b.estimateBasis?str(b.estimateBasis,1500):'',vendor=b.vendor?str(b.vendor,120):'',resolution=b.resolution?str(b.resolution,2000):'',evidence=b.evidence?str(b.evidence,2000):'';
 if(low!==null&&basis.length<5)fail('예상 예산의 견적·산정 근거를 입력해주세요.');if(status==='해결 완료'&&(resolution.length<5||evidence.length<5))fail('해결 내용과 확인 근거를 입력해야 완료로 표시할 수 있습니다.');
 const organization=b.assignedOrganization===undefined?(p.assigned_organization||''):b.assignedOrganization?str(b.assignedOrganization,120):'',department=b.assignedDepartment===undefined?(p.assigned_department||''):b.assignedDepartment?str(b.assignedDepartment,120):'';
 const now=new Date().toISOString();const fields=[['담당 기관',p.assigned_organization||'',organization],['담당 부서',p.assigned_department||'',department],['상태',p.status,status],['우선순위',p.priority,priority],['판단 근거',p.priority_reason,priorityReason],['예상 예산 하한',p.estimate_low,low],['예상 예산 상한',p.estimate_high,high],['예산 근거',p.estimate_basis||'',basis],['업체',p.vendor||'',vendor],['실제 비용',p.spent,spent],['해결 내용',p.resolution||'',resolution],['확인 근거',p.evidence||'',evidence]];
 const detail=fields.filter(([,a,b])=>a!==b).map(([n,a,b])=>`${n}: ${a??'미확인'} → ${b??'미확인'}`).join('\n')+'\n변경 사유: '+reason;
 const results=await database.batch([database.prepare('INSERT INTO events (id, complaint_id, action, detail, actor, created) SELECT ?, id, ?, ?, ?, ? FROM complaints WHERE id = ? AND revision = ?').bind(crypto.randomUUID(),'처리 내역 변경',detail,user.nickname+' ['+user.id+']',now,id,p.revision),database.prepare('UPDATE complaints SET analysis_status=\'manual\',assigned_organization=?,assigned_department=?,status=?,priority=?,priority_reason=?,estimate_low=?,estimate_high=?,estimate_basis=?,vendor=?,spent=?,resolution=?,evidence=?,updated=?,revision=revision+1 WHERE id=? AND revision=?').bind(organization,department,status,priority,priorityReason,low,high,basis,vendor,spent,resolution,evidence,now,id,p.revision)]);
 if(!results[1].meta.changes)fail('다른 변경이 먼저 저장됐습니다. 다시 확인해주세요.',409);return json({saved:true});
 }}fail('요청한 기능을 찾을 수 없습니다.',404);
}
export default {async fetch(req,env,ctx){const url=new URL(req.url);try{if(url.pathname==='/review'||url.pathname==='/review/admin')return Response.redirect(url.origin+(url.pathname.endsWith('/admin')?'/admin':'/'),302);if(url.pathname==='/api/seoul/city'&&req.method==='GET')return json(await cachedPublicRead('city:'+(url.searchParams.get('area')||'잠실 관광특구'),()=>cityStatus(readOnlyEnvironment(env),url.searchParams.get('area')||'잠실 관광특구')));if(url.pathname.startsWith('/api/auth/'))return await auth(req,env,url);if(url.pathname.startsWith('/api/'))return await api(req,env,url,ctx);if(req.method!=='GET')return new Response('Method not allowed',{status:405});let content=PAGE,type='text/html';if(url.pathname==='/style.css'){content=STYLE;type='text/css'}else if(url.pathname==='/app.js'){content=CLIENT;type='application/javascript'}else if(!['/','/admin'].includes(url.pathname))return new Response('Not found',{status:404});return new Response(content,{headers:{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Robots-Tag':'noindex, nofollow', 'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'self'"}})}catch(e){if(!e.status)console.error('moa request failed');return json({error:e.status?e.message:'저장 또는 조회에 실패했습니다. 입력 내용을 유지한 채 다시 시도해주세요.'},e.status||503)}}};
