import {parseObject} from './analysis-service.js';
import {proposeAction} from './actions.js';
// Versioned, explainable rules. Narrative sentiment is never a scoring input.
export const ANALYSIS_VERSION='rules-v5.0';
export const normalizeLocation=s=>s.normalize('NFKC').trim().toLowerCase().replace(/\s+/g,'');
export async function clusterKey(p){
 const scope=p.visibility==='public'?'public':'private:'+p.owner;
 const text=JSON.stringify([p.source||'MOA',p.region,p.district,p.neighborhood,p.category,proposeAction(p).taskId,normalizeLocation(p.location),scope]);
 return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text))),x=>x.toString(16).padStart(2,'0')).join('');
}
const active=p=>!p.deleted_at&&!['해결 완료','제외'].includes(p.status)&&Date.parse(p.created)>Date.now()-90*86400000;
export function assess(p,peers=[]){
 const related=peers.filter(q=>q.cluster_id&&q.cluster_id===p.cluster_id&&active(q));
 if(!related.some(q=>q.id===p.id)&&active(p))related.push(p);
 const reporters=new Set(related.map(q=>q.owner).filter(Boolean)).size;
 const recent=related.filter(q=>Date.parse(q.created)>Date.now()-7*86400000),prior=related.filter(q=>Date.parse(q.created)<=Date.now()-7*86400000&&Date.parse(q.created)>Date.now()-14*86400000);
 const firstReports=new Map();for(const q of related){if(q.owner&&(!firstReports.has(q.owner)||Date.parse(q.created)<Date.parse(firstReports.get(q.owner).created)))firstReports.set(q.owner,q);}const independent=[...firstReports.values()];const recentIndependent=independent.filter(q=>Date.parse(q.created)>Date.now()-7*86400000).length,previousIndependent=independent.filter(q=>Date.parse(q.created)<=Date.now()-7*86400000&&Date.parse(q.created)>Date.now()-14*86400000).length;
 const review=parseObject(p.review);const ageDays=Math.max(0,Math.floor((Date.now()-Date.parse(p.created))/86400000));
 const repeat=Math.min(20,Math.max(0,reporters-1)*5);
 const harm=p.harm_level??0,impact=p.life_impact??(p.obstruction?1:0);
 const risk=p.danger?60:0,damage=harm===3?70:harm===2?25:0,life=impact===2?25:impact===1?20:0;
 let facts={};try{facts=JSON.parse(p.impact_facts||'{}')}catch{}
 const affected=[0,0,5,10][facts.affected]||0,vulnerable=facts.vulnerable&&(risk||life||damage)?10:0,escalation=facts.escalation?10:0;
 const surge=recentIndependent>=3&&recentIndependent>previousIndependent?Math.min(8,(recentIndependent-previousIndependent)*2):0;
 const overdue=review.dueAt&&Date.parse(review.dueAt)<Date.now()&&!['해결 완료','제외'].includes(p.status);
 const unassigned=!p.assigned_department&&ageDays>=7;const urgency=Math.min(12,Math.floor(ageDays/7)+(overdue?5:0)+(unassigned?2:0)),longPending=ageDays>=30;
 const context=review.externalContext||parseObject(p.external_context),city=context.data;
 const mobility=/도로|보도|보행|교통|주정차|대중교통|안전/.test(p.category||'');
 const timely=t=>{if(!t)return false;const ms=Date.parse(String(t).replace(' ','T')+'+09:00');return Number.isFinite(ms)&&Date.now()-ms>=0&&Date.now()-ms<15*60000};
 const externalReasons=[];let external=0;
 if(review.contextVerified&&city&&Date.now()-Date.parse(context.fetchedAt)<15*60000){
 if(mobility&&city.incidents?.some(i=>timely(i.updatedAt))){external+=5;externalReasons.push('관리자가 위치 관계 확인 · 최근 서울시 사고·통제 자료 존재 (민원 원인 확정 아님)')}
 if(mobility&&timely(city.traffic?.updatedAt)&&/정체|서행/.test(city.traffic.level)){external+=3;externalReasons.push('연계 장소 도로 소통 지연 · 통행 영향 보조 근거')}
 if(/침수|배수|결빙|폭설|빙판/.test(p.description||'')&&timely(city.weather?.updatedAt)&&(/비|눈/.test(city.weather.precipitation||'')||Number(city.weather.temperature)<=0)){external+=2;externalReasons.push('관련 기상 상황 · 배수·결빙 현장 확인 필요')}
 if(mobility&&timely(city.population?.updatedAt)&&/붐빔/.test(city.population.level)){external+=2;externalReasons.push('연계 장소 혼잡도 높음 · 영향범위 보조 근거')}
 }
 const facilities=[['학교',/학교|유치원|어린이집/],['병원',/병원|의료원/],['복지시설',/복지관|요양원|경로당/],['역·정류장',/(?:역|정류장).{0,8}(?:앞|옆|인근|근처|주변)|지하철역/]].filter(([,r])=>r.test(p.location+' '+p.description)).map(([n])=>n);const facility=facilities.length&&(risk||life)?(review.facilityVerified?5:2):0;const preciseLocation=/(?:로|길)\s*\d+|(?:출구|정류장|교차로|횡단보도|입구|건물)/.test(p.location||'');const confidence=(review.verified?4:0)+(preciseLocation?1:0);
 const confidenceScore=Math.min(100,(review.verified?60:0)+(preciseLocation?15:0)+(String(p.description||'').length>=30?10:0)+Math.min(15,Math.max(0,reporters-1)*5));const confidenceResult={score:confidenceScore,label:review.verified?'현장 확인됨':'확인 필요',locationSpecific:preciseLocation,independentReporters:reporters,photoVerified:false};
 let score=Math.min(100,external+surge+urgency+facility+Math.max(risk,damage)+life+repeat+affected+vulnerable+escalation);

 // Waiting alone cannot overtake a current safety or injury report.
 if(!risk&&harm!==3)score=Math.min(59,score);
 const reasons=[p.danger?'등록자가 사고 위험을 표시했습니다.':'사고 위험은 표시되지 않았습니다.',harm===3?'등록자가 인명 피해를 표시했습니다.':harm===2?'등록자가 시설·재산 피해를 표시했습니다.':harm===1?'등록자가 확인한 피해가 없다고 표시했습니다.':'실제 피해 정도는 아직 확인되지 않았습니다.',impact===2?'통행 또는 생활 이용 불가로 신고됐습니다.':impact===1?'통행 또는 생활에 불편이 있다고 신고됐습니다.':'통행·생활 영향은 표시되지 않았습니다.',`최근 90일 미해결 유사 신고 ${related.length||1}건 · 신고 계정 ${reporters||1}개. 반복 가점 ${repeat}점.`];
 if(affected)reasons.push('등록자가 여러 이용자에게 영향을 준다고 표시했습니다. 현장 인원은 미검증입니다.');if(vulnerable)reasons.push('어린이·고령자·장애인 등 취약 이용자의 이동에 영향이 있다고 신고됐습니다.');if(escalation)reasons.push('방치 시 피해가 확대될 수 있다고 신고됐습니다.');
 const hazards=[['심각한 침수',/침수|물이 차올|물에 잠/,/도로|지하|차도|보행/],['구조물 낙하 위험',/낙하|떨어지|떨어질|전도/,/구조물|간판|나무|수목|시설/],['어린이보호구역 사고 위험',/어린이보호구역|스쿨존/,/사고|통행 불가|충돌/],['주요 도로 통행 불가',/주요 도로|간선도로/,/통행 불가|통행이 불가능|전면 차단/],['차도·보행로 침하',/싱크홀|지반침하|심각한 침하|땅이 꺼|길 꺼|도로가 꺼|보도가 꺼/,/차도|도로|보행로|보도/],['신호 기능 상실',/신호.{0,10}(고장|꺼|작동하지|상실)/,/교차로|횡단보도/],['붕괴·추락·감전·화재 위험',/붕괴|추락|감전|화재/,/시설|건물|전선|가로등|난간|차도|보도/]];
 const text=((p.description||'')+' '+p.location).split(/[.!?。\n]/).filter(t=>!/아니|아닙|아님|없|오인|잘못 신고|해소|복구 완료/.test(t)).join(' ');const emergencyFactors=hazards.filter(([,a,b])=>a.test(text)&&b.test(text)&&p.danger&&(impact===2||harm===3||facts.escalation)).map(([n])=>n);
 if(p.danger&&harm===3&&facts.vulnerable)emergencyFactors.push('취약 이용자 노출 및 인명 피해 신고');
 const missing=['현장 사실 확인','같은 문제인지 확인'];if(!review.contextVerified)missing.push('서울시 장소와 발생 위치의 관계 확인');
 if(surge)reasons.push(`최근 7일 독립 신고 ${recentIndependent}계정 · 직전 7일 ${previousIndependent}계정보다 증가`);
 if(unassigned)reasons.push('담당부서 미지정 · 7일 이상 경과');if(urgency)reasons.push(overdue?'관리자가 설정한 검토기한 경과':`${ageDays}일 미해결 · 경과시간 반영`);if(facility)reasons.push(`${facilities.join('·')} 인접 ${review.facilityVerified?'업무자 확인':'제보 · 거리 미검증'}`);if(confidence)reasons.push(review.verified?'업무자 현장 확인 기록':'구체적 위치정보 제공');
 reasons.push(...externalReasons);
 reasons.push(`독립 유사신고 ${reporters||1}계정 · 최근 7일 신고 ${recent.length}건`);
 const override=review.priorityOverride;const workScore=override&&Number.isInteger(override.score)?override.score:score;const urgent=review.emergency==='긴급 지정'||(emergencyFactors.length>0&&review.emergency!=='일반 처리');const shortReasons=[...(urgent?emergencyFactors:[]),...(p.danger?['사고위험 제보']:[]),...(harm===3?['인명피해 제보']:harm===2?['시설피해 제보']:[]),...(reporters>1?[`독립신고 ${reporters}건`]:[]),...(facility?[facilities.join('·')+' 인접 '+(review.facilityVerified?'확인':'제보')]:[]),...(surge?['최근 독립신고 증가']:[]),...(externalReasons.length?['서울시 교통·혼잡 근거']:[]),...(impact?['통행·생활 영향']:[]),...(longPending?[`${ageDays}일 미처리`]:[]),...(override?['업무자 순서 조정']:[])].slice(0,4);if(!shortReasons.length)shortReasons.push('현장 확인 필요');
 return {confidence:confidenceResult,workScore,queueUrgent:urgent,queueLabel:urgent?'지금 먼저 확인':workScore>=40?'우선 처리':'일반 처리',shortReasons,priorityOverride:override?{score:override.score,reason:override.reason,updatedAt:override.updatedAt}:null,facilityClaims:facilities,review,ageDays,overdue:!!overdue,recentCount:recent.length,recentIndependent,previousIndependent,emergency_candidate:emergencyFactors.length>0,emergency_factors:emergencyFactors,emergency_decision:review.emergency||'미검토',evidenceConfidence:review.verified?'관리자 현장 확인 기록 있음':'신고자 진술 · 검증 전',missing_information:missing,version:ANALYSIS_VERSION,method:'rules',score,priority:score>=60?3:score>=20?2:1,reasons,reportCount:related.length||1,reporterCount:reporters||1,components:{facility,safety:risk,harm:damage,impact:life,repeat,affected,vulnerable,escalation,surge,urgency,external},limitations:['신고자가 입력한 정보이며 현장 검증 전입니다.','지역·장소 표기·유형이 일치하는 후보만 묶습니다. 같은 문제인지 최종 확인이 필요합니다.','동일 계정의 반복 등록은 반복 가점을 높이지 않습니다.','서울시 정보는 관리자 위치 관계 확인과 원본 자료 시각의 최신성이 모두 충족된 경우만 보조 가점에 사용합니다.'],externalContextUsedForScore:external>0};
}
export function decorate(p,peers){
 const analysis=assess(p,peers),manual=p.analysis_status==='manual'||!p.analysis_version;
 return {...p,actionProposal:proposeAction(p),priority:manual?p.priority:analysis.priority,priority_reason:manual?p.priority_reason:analysis.reasons.join(' '),assessment:analysis,priorityMode:manual?'운영자 검토':'규칙 기반',similarCount:analysis.reportCount};
}

export function compareWork(a,b){const closed=p=>['해결 완료','제외'].includes(p.status);return Number(closed(a))-Number(closed(b))||Number(!!b.assessment?.queueUrgent)-Number(!!a.assessment?.queueUrgent)||(b.assessment?.workScore??b.assessment?.score??0)-(a.assessment?.workScore??a.assessment?.score??0)||Date.parse(a.created)-Date.parse(b.created)||a.id.localeCompare(b.id);}
