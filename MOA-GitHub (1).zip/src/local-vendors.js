import {proposeAction} from './actions.js';
// Kakao Local REST API. Only server-side Authorization header contains the key.
// No raw upstream errors or requests are logged or returned.
const SOURCE='https://developers.kakao.com/docs/ko/local/dev-guide';
const memo=new Map();
export function localTrade(p){const a=proposeAction(p);return a.taskId?{label:a.label,queries:a.keywords,stages:a.searchStages,match:new RegExp(a.localCategoryPattern),notice:a.notice,taskId:a.taskId}:null;}
export function locationQuery(p){
 const landmark=String(p.location||'').split(/(?:부근|인근|주변|앞|옆|근처)/)[0].replace(/(?:파손|고장|사고|발생|불편).*$/,'').trim();
 if(landmark.length<2)return null;
 return {landmark,query:/^서울(?:특별시)?\s/.test(landmark)?landmark:[p.region||'서울특별시',landmark.includes(p.district)?'':p.district,landmark].filter(Boolean).join(' ')};
}
export function distanceMeters(a,b){const rad=x=>x*Math.PI/180;const dy=rad(b.y-a.y),dx=rad(b.x-a.x);const v=Math.sin(dy/2)**2+Math.cos(rad(a.y))*Math.cos(rad(b.y))*Math.sin(dx/2)**2;return Math.round(6371000*2*Math.atan2(Math.sqrt(v),Math.sqrt(Math.max(0,1-v))))}
const point=d=>{const x=Number(d.x),y=Number(d.y);return Number.isFinite(x)&&Number.isFinite(y)&&x>=124&&x<=132&&y>=33&&y<=39?{x,y}:null};
export async function localVendors(env,p){
 const key=env.KAKAO_REST_API_KEY?.trim();const trade=localTrade(p),location=locationQuery(p);
 const base={source:'KAKAO_LOCAL',sourceUrl:SOURCE,candidates:[],trade:trade?.label||null,notice:trade?.notice||'',radius:0,fetchedAt:new Date().toISOString(),diagnostics:[]};
 if(!key)return {...base,status:'not_configured',message:'지역 민간업체 정보를 현재 불러올 수 없습니다.'};
 if(!trade)return {...base,status:'needs_review',message:'필요한 작업을 먼저 확인해야 합니다.'};
 if(!location)return {...base,status:'location_required',message:'민원 위치를 더 구체적으로 확인해야 합니다.'};
 const cacheKey=JSON.stringify([p.id,p.revision,p.location,p.category,p.description,p.review]);const old=memo.get(cacheKey);if(old&&old.until>Date.now())return old.promise;
 const run=async()=>{
 const diagnostics=[];
 async function request(kind,params){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),7000);
  try{const r=await fetch('https://dapi.kakao.com/v2/local/search/'+kind+'.json?'+new URLSearchParams(params),{headers:{Authorization:'KakaoAK '+key},signal:controller.signal,redirect:'manual'});
   let body;try{body=await r.json()}catch{body={}}const errorCode=Number.isInteger(body.code)?body.code:null;diagnostics.push({operation:kind,httpStatus:r.status,code:errorCode});
   if(!r.ok)throw Object.assign(Error('API_UNAVAILABLE'),{safe:true});
   return Array.isArray(body.documents)?body.documents:[];
  }catch(error){if(!error?.safe)diagnostics.push({operation:kind,httpStatus:null,code:null,failure:error?.name==='AbortError'?'TIMEOUT':/redirect/i.test(String(error?.message||''))?'REDIRECT_MODE_UNSUPPORTED':'NETWORK_OR_RUNTIME_ERROR'});throw error}finally{clearTimeout(timer)}
 }
 try{
 let center=null;
 const addresses=await request('address',{query:location.query,analyze_type:'exact',size:'5'});
 const inDistrict=d=>(d.address_name||d.address?.address_name||'').includes(p.district);
 const validAddresses=addresses.filter(d=>inDistrict(d)&&point(d));
 if(validAddresses.length===1){const d=validAddresses[0];center={...point(d),label:d.road_address?.address_name||d.address_name,method:'address',precision:'주소 기준 · 현장 지점 확인 필요'}}
 if(!center){
  const places=await request('keyword',{query:location.query,size:'15'});
  const normalized=s=>s.replace(/[\s()·]/g,'').replace(/아파트/g,'');const needle=normalized(location.landmark);
  const matches=places.filter(d=>inDistrict(d)&&point(d)&&normalized(d.place_name).includes(needle));
  const exact=matches.filter(d=>normalized(d.place_name)===needle);const choices=exact.length?exact:matches;
  if(choices.length===1){const d=choices[0];center={...point(d),label:d.place_name,address:d.road_address_name||d.address_name,method:'landmark',precision:'주변 장소 기준 · 실제 민원 지점과 다를 수 있음'}}
 }
 if(!center)return {...base,status:'location_required',message:'위치를 하나로 특정하지 못했습니다. 도로명 주소나 정확한 시설명이 필요합니다.',diagnostics};
 const found=new Map();let radius=0,successfulSearches=0,searchCount=0;const searchStarted=Date.now();
 search: for(const r of [2000,5000,10000,20000]){
 for(const stage of trade.stages||[{level:0,queries:trade.queries}]){
 if(searchCount>=36||Date.now()-searchStarted>22000)break search;
  radius=r;
  const batches=await Promise.all(stage.queries.map(async(query,queryIndex)=>{searchCount++;try{const rows=await request('keyword',{query,x:String(center.x),y:String(center.y),radius:String(r),sort:'distance',size:'15'});successfulSearches++;return {query,queryIndex,rows};}catch{return {query,queryIndex,rows:[]}}}));
  for(const {queryIndex,query,rows} of batches){
   for(const d of rows){const pos=point(d);if(!pos||!trade.match.test(d.category_name||'')||/보관소|충전소|주차장|경찰|구청|시청/.test(d.place_name+' '+d.category_name))continue;const distance=distanceMeters(center,pos);if(distance>r+20||!/^https?:\/\/place\.map\.kakao\.com\/\d+$/.test(d.place_url||''))continue;
    if(found.has(d.id)&&found.get(d.id).relevance>=(stage.level<=2?3:stage.level===3?2:1))continue;found.set(d.id,{id:d.id,name:d.place_name,address:d.road_address_name||d.address_name,category:d.category_name,distanceMeters:distance,providerDistanceMeters:/^\d+$/.test(d.distance||'')?Number(d.distance):null,url:d.place_url,matchedQuery:query,searchStage:stage.label,source:'KAKAO_LOCAL',industryFit:1,performanceCount:0,relevance:(stage.level<=2?3:stage.level===3?2:1)});
   }
  }
  if(found.size>=3)break search;
 }
 }
 const candidates=[...found.values()].sort((a,b)=>b.relevance-a.relevance||a.distanceMeters-b.distanceMeters).slice(0,5);
 // Defense in depth: never allow a reflected secret in a provider field.
 for(const v of candidates)for(const k of Object.keys(v))if(typeof v[k]==='string'&&v[k].includes(key))v[k]='';
 return {...base,status:candidates.length?'ok':successfulSearches?'empty':'unavailable',partial:diagnostics.some(x=>x.httpStatus!==200),center,radius,candidates,searchCount,searchLimited:searchCount>=36||Date.now()-searchStarted>22000,diagnostics,message:candidates.length?'':'현재 조건에 맞는 후보를 확인하지 못했습니다.',distanceBasis:'기준점과 업체 좌표 간 직선거리 · 이동 거리 아님'};
 }catch{return {...base,status:'unavailable',message:'지역 민간업체 정보를 현재 불러올 수 없습니다.',diagnostics}}
 };
 if(memo.size>=100)memo.delete(memo.keys().next().value);const promise=run();memo.set(cacheKey,{promise,until:Date.now()+300000});return promise;
}
