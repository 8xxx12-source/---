import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';
export const complaints = sqliteTable('complaints', {
 id:text('id').primaryKey(), region:text('region').notNull(), district:text('district').notNull(), neighborhood:text('neighborhood').notNull(),
 location:text('location').notNull(), category:text('category').notNull(), description:text('description').notNull(), danger:integer('danger').notNull(), obstruction:integer('obstruction').notNull(),
 priority:integer('priority').notNull(), priorityReason:text('priority_reason').notNull(), status:text('status').notNull().default('접수'),
 estimateLow:integer('estimate_low'), estimateHigh:integer('estimate_high'), estimateBasis:text('estimate_basis'), vendor:text('vendor'), spent:integer('spent'), resolution:text('resolution'), evidence:text('evidence'),
 source:text('source').notNull().default('MOA'), sourceId:text('source_id'), sourceUrl:text('source_url'), sourceUpdatedAt:text('source_updated_at'), syncedAt:text('synced_at'), sourceLicense:text('source_license'), regionMetadata:text('region_metadata'), analysisStatus:text('analysis_status').notNull().default('pending'), analysisVersion:text('analysis_version'), clusterId:text('cluster_id'), harmLevel:integer('harm_level'), safetyRisk:integer('safety_risk'), lifeImpact:integer('life_impact'), analysisEvidence:text('analysis_evidence'),
 review:text('review'),impactFacts:text('impact_facts'),deletedAt:text('deleted_at'),deletedBy:text('deleted_by'),deleteReason:text('delete_reason'),cancelRequestedAt:text('cancel_requested_at'),cancelReason:text('cancel_reason'),
 assignedOrganization:text('assigned_organization'),assignedDepartment:text('assigned_department'),
 visibility:text('visibility').notNull().default('private'), externalContext:text('external_context'),
 owner:text('owner').notNull(), created:text('created').notNull(), updated:text('updated').notNull(), revision:integer('revision').notNull().default(1)
},t=>[index('idx_complaints_cluster').on(t.clusterId),index('idx_complaints_region').on(t.region,t.district,t.neighborhood)]);
export const events=sqliteTable('events', {id:text('id').primaryKey(), complaintId:text('complaint_id').notNull().references(()=>complaints.id), action:text('action').notNull(), detail:text('detail').notNull(), actor:text('actor').notNull(), created:text('created').notNull()},t=>[index('idx_events_complaint').on(t.complaintId,t.created)]);
export const loginAttempts=sqliteTable('login_attempts',{id:text('id').primaryKey(),window:integer('window').notNull(),attempts:integer('attempts').notNull()});
export const sessions=sqliteTable('sessions',{token:text('token').primaryKey(),expires:integer('expires').notNull(),userId:text('user_id')});

export const users=sqliteTable('users',{id:text('id').primaryKey(),username:text('username').notNull().unique(),nickname:text('nickname').notNull(),passwordHash:text('password_hash').notNull(),passwordSalt:text('password_salt').notNull(),passwordIterations:integer('password_iterations').notNull().default(100000),role:text('role').notNull().default('USER'),created:text('created').notNull()});
export const cityCache=sqliteTable('city_cache',{area:text('area').primaryKey(),lastError:text('last_error'),lastAttemptAt:integer('last_attempt_at'),payload:text('payload'),fetchedAt:integer('fetched_at'),retryAfter:integer('retry_after').notNull().default(0)});

export const procurementCache=sqliteTable('procurement_cache',{id:text('id').primaryKey(),diagnostic:text('diagnostic'),payload:text('payload').notNull(),fetchedAt:integer('fetched_at').notNull()});
