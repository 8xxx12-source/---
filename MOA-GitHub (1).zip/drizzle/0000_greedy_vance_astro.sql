CREATE TABLE `complaints` (
	`id` text PRIMARY KEY NOT NULL,
	`region` text NOT NULL,
	`district` text NOT NULL,
	`neighborhood` text NOT NULL,
	`location` text NOT NULL,
	`category` text NOT NULL,
	`description` text NOT NULL,
	`danger` integer NOT NULL,
	`obstruction` integer NOT NULL,
	`priority` integer NOT NULL,
	`priority_reason` text NOT NULL,
	`status` text DEFAULT '접수' NOT NULL,
	`estimate_low` integer,
	`estimate_high` integer,
	`estimate_basis` text,
	`vendor` text,
	`spent` integer,
	`resolution` text,
	`evidence` text,
	`owner` text NOT NULL,
	`created` text NOT NULL,
	`updated` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_complaints_region` ON `complaints` (`region`,`district`,`neighborhood`);--> statement-breakpoint
CREATE TABLE `events` (
	`id` text PRIMARY KEY NOT NULL,
	`complaint_id` text NOT NULL,
	`action` text NOT NULL,
	`detail` text NOT NULL,
	`actor` text NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`complaint_id`) REFERENCES `complaints`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_events_complaint` ON `events` (`complaint_id`,`created`);