ALTER TABLE `complaints` ADD `deleted_at` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `deleted_by` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `delete_reason` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `cancel_requested_at` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `cancel_reason` text;