ALTER TABLE `complaints` ADD `source` text DEFAULT 'MOA' NOT NULL;--> statement-breakpoint
ALTER TABLE `complaints` ADD `source_id` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `source_url` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `source_updated_at` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `synced_at` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `source_license` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `region_metadata` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `analysis_status` text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `complaints` ADD `analysis_version` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `cluster_id` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `harm_level` integer;--> statement-breakpoint
ALTER TABLE `complaints` ADD `safety_risk` integer;--> statement-breakpoint
ALTER TABLE `complaints` ADD `life_impact` integer;--> statement-breakpoint
ALTER TABLE `complaints` ADD `analysis_evidence` text;