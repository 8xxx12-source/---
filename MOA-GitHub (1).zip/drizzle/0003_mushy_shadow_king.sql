CREATE TABLE `city_cache` (
	`area` text PRIMARY KEY NOT NULL,
	`payload` text,
	`fetched_at` integer,
	`retry_after` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`nickname` text NOT NULL,
	`password_hash` text NOT NULL,
	`password_salt` text NOT NULL,
	`password_iterations` integer DEFAULT 100000 NOT NULL,
	`role` text DEFAULT 'USER' NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `users_username_unique` ON `users` (`username`);--> statement-breakpoint
ALTER TABLE `complaints` ADD `visibility` text DEFAULT 'private' NOT NULL;--> statement-breakpoint
ALTER TABLE `complaints` ADD `external_context` text;--> statement-breakpoint
ALTER TABLE `sessions` ADD `user_id` text;