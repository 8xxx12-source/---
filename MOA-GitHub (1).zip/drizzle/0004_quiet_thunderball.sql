ALTER TABLE `city_cache` ADD `last_error` text;--> statement-breakpoint
ALTER TABLE `city_cache` ADD `last_attempt_at` integer;--> statement-breakpoint
ALTER TABLE `complaints` ADD `assigned_organization` text;--> statement-breakpoint
ALTER TABLE `complaints` ADD `assigned_department` text;--> statement-breakpoint
CREATE INDEX `idx_complaints_cluster` ON `complaints` (`cluster_id`);